
package in.cdac.action;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.cdac.dao.StorageDao;
import in.cdac.dao.Storage;


@WebServlet("/storage-action")
public class StorageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
		String productName= request.getParameter("productName");
		String productRate= request.getParameter("productRate");
		String updatedDate= request.getParameter("updatedDate");

		Storage storage = new Storage(productName,productRate,updatedDate);
		System.out.println(productName + productRate + updatedDate);
		 
		StorageDao dao = new StorageDao();
		dao.createStorage(storage);
		
		 response.sendRedirect("/SupermarketBillingSystem/storage.jsp?q=1");
		}
		catch(Exception e) {
			e.printStackTrace();
			 response.sendRedirect("/SupermarketBillingSystem/storage.jsp?q=0");
		}
	}

}
