package in.cdac.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.cdac.dao.*;

@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		try{
			ProductDao dao = new ProductDao();
			
			List <Storage> productlist = dao.readall();
			
			request.setAttribute("productlist", productlist);
			request.getRequestDispatcher("product.jsp?q==0").forward(request, response);
//			response.sendRedirect("/practice3/read.jsp?=1");
		}catch(Exception e) {
			
			request.getRequestDispatcher("product.jsp?q==1").forward(request, response);
		}
	
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}

