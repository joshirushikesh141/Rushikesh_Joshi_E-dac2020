
package in.cdac.action;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.cdac.dao.LoginDao;
import in.cdac.dao.User;

/**
 * Servlet implementation class LoginAction
 */
@WebServlet("/login-action")
public class LoginUserAction extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			
			LoginDao dao = new LoginDao();
			User user = new User(null,null,null,null,null,null,null,null,null, username, password);
			boolean check =  dao.authenticateUser(user);
			
			if(check == true) {
				response.sendRedirect("customer.jsp");
			} else {
				throw new Exception("Auth Fails");	
			}
			
		} catch(Exception e) {
			e.printStackTrace();
			response.sendRedirect("login.jsp?q=0");
		}
	}

}
