
package in.cdac.action;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.cdac.dao.CustomerDao;
import in.cdac.dao.Customer;


@WebServlet("/customer-action")
public class CustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
		String customerName= request.getParameter("customerName");
		String customerMobile= request.getParameter("customerMobile");

		Customer customer = new Customer(customerName,customerMobile);
		 
		CustomerDao dao = new CustomerDao();
		dao.createCustomer(customer);
		
		 response.sendRedirect("/SupermarketBillingSystem/customer.jsp?q=1");
		}
		catch(Exception e) {
			e.printStackTrace();
			 response.sendRedirect("/SupermarketBillingSystem/customer.jsp?q=0");
		}
	}

}

