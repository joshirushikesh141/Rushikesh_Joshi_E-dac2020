package in.cdac.action;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.cdac.dao.RegisterDao;
import in.cdac.dao.User;


@WebServlet("/register-action")
public class RegisterUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
		String name= request.getParameter("name");
		String dateOfBirth= request.getParameter("dateOfBirth");
		String gender= request.getParameter("gender");
		String email= request.getParameter("email");
		String mobile= request.getParameter("mobile");
		String address= request.getParameter("address");
		String pincode= request.getParameter("pincode");
		String aadhaarNumber= request.getParameter("aadhaarNumber");
		String workExperience= request.getParameter("workExperience");
		String username= request.getParameter("username");
		String password= request.getParameter("password");
		
		
		User user = new User(name,dateOfBirth,gender,email,mobile,address,pincode,aadhaarNumber,workExperience,username,password);
		
		RegisterDao dao = new RegisterDao();
		dao.createUser(user);
		
		response.sendRedirect("/SupermarketBillingSystem/register.jsp?q=1");
		}
		catch(Exception e) {
			e.printStackTrace();
			response.sendRedirect("/SupermarketBillingSystem/register.jsp?q=0");
		}
	}

}
