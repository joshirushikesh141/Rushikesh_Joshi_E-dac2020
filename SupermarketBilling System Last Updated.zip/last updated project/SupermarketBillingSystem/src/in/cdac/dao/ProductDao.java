package in.cdac.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class ProductDao {

	private static final SessionFactory sessionfactory = new Configuration().configure().buildSessionFactory();

	public boolean createUser(Storage storage) {

		try {

			Session session = sessionfactory.openSession();
			session.beginTransaction();
			
			session.save(storage);
			
			session.getTransaction().commit();
			return true;

		} catch (Exception e) {
			return false;
		}
	}

	public List<Storage> readall(){
	
			Session session = sessionfactory.openSession();
			session.beginTransaction();
			String sql = "SELECT * FROM storage";
			
			List <Storage> userlist =  session.createNativeQuery(sql, Storage.class).list();

			return userlist;					
	}
}
