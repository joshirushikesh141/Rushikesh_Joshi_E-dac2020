package in.cdac.dao;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="storage")
public class Storage {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int srNo;
	private String productName;
	private String productRate;
	private String updatedDate;
	
	
	public Storage(String productName, String productRate, String updatedDate) {
		super();
		// this.srNo = new Random().nextInt(100000);
		this.productName = productName;
		this.productRate = productRate;
		this.updatedDate = updatedDate;
	}
	

	public Storage() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getSrNo() {
		return srNo;
	}
	public void setSrNo(int srNo) {
		this.srNo = srNo;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductRate() {
		return productRate;
	}
	public void setProductRate(String productRate) {
		this.productRate = productRate;
	}
	public String getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}	
	
}