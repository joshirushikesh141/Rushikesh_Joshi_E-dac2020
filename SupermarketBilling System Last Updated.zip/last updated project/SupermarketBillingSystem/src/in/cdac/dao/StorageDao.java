package in.cdac.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class StorageDao {
	private static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();

	public void createStorage(Storage storage) {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		
		session.save(storage);
		
		session.getTransaction().commit();
		session.close();	
	}
}
