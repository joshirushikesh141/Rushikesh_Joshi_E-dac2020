package SupermarketBillingSystem;
import java.util.*;
import java.io.*;
class Student
{
	int rollNo;
	String name;
	double marks;
	
	public int getRollNo()
	{
		return rollNo;
	}
	public void setRollNo(int rollNo)
	{
		this.rollNo=rollNo;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public double getMarks()
	{
		return marks;
	}
	public void setMarks(double marks)
	{
		this.marks=marks;
	}
	public String toString()
	{
		//return ""+rollNo+"\t"+name+"\t"+marks;
                return ""+name;
	}
}

class FileReadToBean
{
	
	public static void main(String args[]) throws IOException
	{
		
		ArrayList <Student> studList = new ArrayList <Student>();
		FileReader fr = new FileReader("C:\\Users\\HP\\Desktop\\Project Work\\student_marks.txt");
		
		BufferedReader br = new BufferedReader(fr);
		
		String line = null;
		while(((line = br.readLine())) != null)
		{
			String str[] = line.split(",");
			Student s = new Student();
			s.setRollNo(Integer.parseInt(str[0]));
			s.setName(str[1]);
			s.setMarks(Double.parseDouble(str[2]));
			
			studList.add(s);
		}
		br.close();
		
		for(Student s: studList)
		{
			System.out.println(s);
		}
	}
}