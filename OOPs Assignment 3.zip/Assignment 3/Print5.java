class Print5
{
public static void main(String args[])
 {
  float a = 4.5f;
  float b = 7.5f;
  float c = a + b;
  System.out.println(" c is ="+c); 
    
  }
}