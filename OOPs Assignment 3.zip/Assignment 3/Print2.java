class Print2
{
public static void main(String args[])
 {
  int a = 10;
  double f = a;
  System.out.println(a);
  System.out.println(f); 
    
  }
}