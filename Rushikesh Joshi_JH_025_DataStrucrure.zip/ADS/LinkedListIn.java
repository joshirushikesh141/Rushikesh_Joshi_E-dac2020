//import DSArraypack.LinkedListDemo;
//import DSArraypack.LinkedListOP;

//import java.nio.channels.ClosedSelectorException;

public class LinekdListIn {

        Node head;
        Node tail;

        static class Node {
            int data;
            Node next;

            Node(int data) {
                this.data = data;
                next = null;
            }
        }
        public void PrintList()
        {
            Node n=head;
            while(n!=null)
            {
                System.out.println(n.data+"");
                n=n.next;
            }
        }
        public static void main(String []args)
        {
            LinekdListIn lst=new LinekdListIn();

            lst.insertAtBeg(10);
            lst.insertAtBeg(20);
            lst.insertAtBeg(30);
           // lst.insertAtMid(40);

            lst.PrintList();
        }



        public void insertNode(int data)
        {
            LinekdListIn ln=new LinekdListIn();
            Node n=new Node(data);
            n.next=null;

        }


    void insertAtBeg(int ele) {
        Node newNode = new Node(ele);
        newNode.next = head;
        head = newNode;


    }

    void deleteAtBeg()
    {
        if(head==null)
        {
            System.out.println("List is empty");
            return;
        }
        else
            if(head!=tail)
            {
                head=head.next;
            }
        else
            {
                head=tail=null;
            }
    }
}