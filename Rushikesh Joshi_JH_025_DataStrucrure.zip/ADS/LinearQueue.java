public class LinearQueue 
{
	int front=-1,rear=-1;
	int n=10;
	int[] a=new int[n];
	
	boolean isempty()
	{
		return (front==-1 && rear==-1);
	}
	
	public void insert(int ele)
	{
		if(rear==n-1)
		{
			System.out.println("Queue is full");
		}
		
		if(front==-1 && rear==-1)
		{
			front=0;
			rear=0;
		}
		else
		{
			rear=rear+1;
		}
		a[rear]=ele;
	}
	
	public void display()
	{
		for(int i=front;i<=rear;i++)
		{
			System.out.println(a[i]);
		}
	}
	
	public void delete()
	{
		if(front==-1 || rear<front)
		{
			System.out.println("Queue is Empty");
		}
		else
		{
			front++;
		}
	}
	
	public static void main(String args[])
	{
		LinearQueue P=new LinearQueue();
		P.insert(10);
		P.insert(20);
		P.insert(30);
		P.display();
		P.delete();
		P.display();
	}
}
