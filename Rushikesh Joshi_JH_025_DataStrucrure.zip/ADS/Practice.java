class MyStack
{
	int[] stack;
	static int top;
	static int MAX=100;
	
	MyStack()
	{
		top=0;
		stack=new int[MAX];
	}
	public void push(int a)
	{
		if(top>MAX)
		{
			System.out.println("error:Stack is full");
		}
		else
			stack[top++]=a;
			//System.out.println(a);            // data we are pushing in
			//System.out.println(stack[top]);     //its giving answer 0
			//System.out.println(stack[top-1]);   // it gives proper answer
	}
	public int pop()
	{
		if(top<0)
		{
			System.out.println("error:Stack is Empty");
			return -1;
		}
		else
			return stack[--top];
	}
}
class Practice
{
	public static void main(String args[])
	{
		MyStack s = new MyStack();
		for(int i=101; i<200; i++)
		{
			s.push(i);
		}
		for(int i=s.top-1; i>=0; i--)
		{
		System.out.println(s.pop());
		}
	
	}
}