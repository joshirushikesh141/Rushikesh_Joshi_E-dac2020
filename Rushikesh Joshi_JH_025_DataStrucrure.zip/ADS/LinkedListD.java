class LinkedList
{
	Node head;
	Node tail;
	static class Node
	{
		int data;
		Node next;
		
		Node(int d)
		{
			data = d;
			next = null;
		}
	}
	public void printList()
	{
		Node n = head;  	//taking new pointer n
		while(n != null)	//traversing
		{
			System.out.println(n.data+" ");
			n = n.next;
		}
	}
	
	public void insertAtBig(int d)
	{
		Node newN = new Node(d);   //new node creation
		if(head == null)
		{
			head = newN;
			tail = newN;
		}
		else
		{
			newN.next = head;    // next of newN becomes head of a
			head = newN;         // head points to newN
		}
	}
	public void insertAtEnd(int d)
	{
		Node newN = new Node(d);
		if(head==null)
		{
			head = newN;		
			tail = newN;
		}
		else
		{
			tail.next = newN;	//next of tail node points to newN
			tail=newN;			// newN becomes tail
		}
	}
	public void insertAtMiddle(int pos, int d)
	{
		Node newN = new Node(d);
		Node temp=head;
		
		for(int i=1; i<pos-1; i++)
		{
			temp=temp.next;
		}
		newN.next =temp.next;
		temp.next=newN;
	}
	public void delAtBeg()
	{
		if(head==null)
		{
			System.out.println("Linked List is Empty");
		}
		else
		{
			int x;
			x= head.data;	//head data assigned to x
			head=head.next;	//head shifted to next node
			System.out.println(x+"Element deleted Successfully");
		}
	}
	public void delAtEnd()
	{
		Node n=head;
		if(head==null)
		{
			System.out.println("Linked List is Empty");
		}
		else
		{
			if(n.next==tail)
			{
				n.next=null;
				n=tail;
			}
			else
			{
				n=n.next;
			}
			System.out.println(n.data+"Element Deleted Successfully");
		}
	}
	void delAtMiddle(int pos)
	{
		Node temp= head;
		if(head==null)
		{
			System.out.println("Linked List is Empty");
		}
		else
		{	
			for(int i=1; i<pos-1; i++)
			{
				temp=temp.next;
			}
				temp.next=temp.next.next;
		}
	}
}
class LinkedListD
{
	public static void main(String args[])
	{
	LinkedList l1 =new LinkedList();
	l1.insertAtBig(10);
	l1.insertAtBig(20);
	l1.insertAtBig(30);
	l1.insertAtBig(40);
	l1.printList();
	}
}







