class LinkedList
{
	Node head=null;
	static class Node
	{
		int data;
		Node next;
		
		Node(int data)
		{
			this.data=data;
			next=null;
		}
	}
	
	public void insertFront(int data)
	{
		Node n = new Node(data); //new node creation
		n.next=head;             //created node's next point to head
		head=n;					 // head should point to n
	}
	
	public void delete(int data) //only for middle and (last?) element
	{
		Node temp,prev=null;
		temp=head;
		while(temp != null && temp.data!=data)
		{
			prev=temp;
			temp=temp.next;
		}
		prev.next=temp.next;
	}
	
	public void insertAtPosition(Node prev, int data)
	{
		Node n = new Node(data); //new node inserts after prev node
		Node temp;      // variable declaration
	//just swaping of pointers
		temp=prev.next; //store next pointer of previous node into temp 
		prev.next=n;    //prev.next point to new node
		n.next=temp;    //new node's next points to temp
	}
	
	public void insertend(int data)
	{
		Node n = new Node(data);
		Node temp= head;
		Node prev=null;
		while(temp != null)  //taken for traversing
		{
			prev=temp;
			temp=temp.next;
		}
		prev.next=n;
		n.next=null;
	}
	
	public void printList()
	{
		Node temp=head;
		while(temp != null)
		{
			System.out.println(temp.data);
			temp=temp.next; 
		}
	}
	
	public static void main(String args[])
	{
		LinkedList l1= new LinkedList();
		Node first= new Node(1);
		l1.head=first;
		Node second= new Node(2);
		first.next=second;
		Node third= new Node(4);
		second.next=third;
		Node forth= new Node(5);
		third.next=forth;
		
		
		l1.insertAtPosition(second,3); // 3 put after 2nd node
		l1.insertFront(0);			   // insert 0 at front
		l1.insertend(6);			   // insert 6 at end
		l1.printList();
		System.out.println("------------");
		l1.delete(5);
		l1.delete(2);
		l1.delete(6);
		l1.printList();
		
	}
}











