public class DoublyLinkedList {
	private Node1 head;
    private Node1 tail;

    public DoublyLinkedList() 
    {
        head = null;
        tail = null;
    } 
    
    public boolean isEmpty() {
        return head == null;
    }
    
    public void insertAtFront(int ele) 
    {
        Node1 node = new Node1(ele);
        if(isEmpty()) {
            head = node;
            tail = node;
        } else {
            node.next = head;
            head.prev = node;
            head = node;
        }
    }
    
    public void insertAtback(int ele) 
    {
        Node1 node = new Node1(ele);
        if(isEmpty()) {
            head = node;
            tail = node;
        } else {
            node.prev = tail;
            tail.next= node;
            tail = node;
        }
    }
    
    public void insertAfter(int key, int ele)
    {
    	Node1 node = new Node1(ele);

    		// find the position of key
    		Node1 curr = head;
    		while(null != curr && curr.data != key)
    		{
    			curr = curr.next;
    		}

    		if (null == curr) 
    		{
    			System.out.println("Key not found");
    			return;
    		}

    		if(null == curr.next) 
    		{
    			curr.next = node;
    			node.prev = curr;
    			tail = node;
    		} 
    		else 
    		{
    			Node1 next = curr.next;
    			curr.next = node;
    			node.prev = curr;
    			node.next = next;
    			next.prev = node;
    		}
    }
    
    public void insertAt(int pos, int ele)
    {
    	Node1 node = new Node1(ele);
           int i=0;
    		// find the position of key
    		Node1 curr = head;
    		while(i<pos-1)
    		{
    			curr = curr.next;
    			i++;
    		}

    		if (null == curr) 
    		{
    			System.out.println("Key not found");
    			return;
    		}

    		if(null == curr.next) 
    		{
    			curr.next = node;
    			node.prev = curr;
    			tail = node;
    		} 
    		else 
    		{
    			Node1 next = curr.next;
    			curr.next = node;
    			node.prev = curr;
    			node.next = next;
    			next.prev = node;
    		}
    }
    
    public void printfromfront()
    {
   	 Node1 curr=head;
        if (isEmpty()) {
            System.out.println("List is Empty");
        } else {
       	
            while (curr != null) {
                System.out.print(curr.data + " ");
                curr = curr.next;
            }
            System.out.println();
        }
    }
    
    public void printfromback()
    {
   	 Node1 curr=tail;
        if (isEmpty()) {
            System.out.println("List is Empty");
        } else {
       	
            while (curr != null) {
                System.out.print(curr.data + " ");
                curr = curr.prev;
            }
            System.out.println();
        }
    }
    
    public void deleteattop()
    {
      if(isEmpty())
        {
    	  System.out.println("List is empty");
        }
      else
      {
    	  Node1 next=head.next;
    	  if (next != null) {
              next.prev = null;
          }
          head = next;
      }
    }
    
    public void deleteatback()
    {
      if(isEmpty())
        {
    	  System.out.println("List is empty");
        }
      else
      {
    	  Node1 next=tail.prev;
    	  if (next != null) {
              next.next = null;
          }
          tail = next;
      }
    }
    
    public void delete(int key) {
        if (isEmpty()) {
            System.out.println("List is empty");
            return;
        }
        // find the position of the key
        Node1 curr = head;
        while(curr != null && curr.data != key) {
            curr = curr.next;
        }

        if(curr == null) {
            System.out.print("key not found");
            return;
        }
        // if curr is head, delete the head
        if (curr.prev == null) {
            deleteattop();

        } else if (curr.next == null) { // if curr is last item
            deleteatback();

        } else { //anywhere between first and last node
            Node1 next = curr.next;
            Node1 prev = curr.prev;

            prev.next = next;
            next.prev = prev;

            curr.prev = null;
            curr.next = null;
            curr = null;
        }   
    }
    
    public void deleteat(int pos) {
        if (isEmpty()) {
            System.out.println("List is empty");
            return;
        }
        int i=0;
        // find the position of the key
        Node1 curr = head;
        while(i<pos) {
            curr = curr.next;
            i++;
        }

        if(curr == null) {
            System.out.print("key not found");
            return;
        }
        // if curr is head, delete the head
        if (curr.prev == null) {
            deleteattop();

        } else if (curr.next == null) { // if curr is last item
            deleteatback();

        } else { //anywhere between first and last node
            Node1 next = curr.next;
            Node1 prev = curr.prev;

            prev.next = next;
            next.prev = prev;

            curr.prev = null;
            curr.next = null;
            curr = null;
        }   
    }
    //Searching operation
    public void find(int key) {
        if (isEmpty()) {
            System.out.println("List is empty");
        }

        Node1 curr = head;
        while(curr != null && curr.data != key) {
            curr = curr.next;
        }

        if (curr == null) {
        	System.out.println("Element is Not found");		
        }
        else
        {
        System.out.println(curr.data+" "+"Element is found");	
        }
    }
    
    
    public static void main(String args[])
    {
    	DoublyLinkedList d=new DoublyLinkedList();
    	d.insertAtFront(20);
    	d.insertAtFront(10);
    	d.insertAtFront(5);
    	d.insertAtback(30);
    	d.insertAfter(10,15);
    	d.insertAfter(20, 25);
    	d.insertAt(3, 17);
    	d.printfromfront();
    	d.printfromback();
    	//d.deleteattop();
    	//d.deleteatback();
    	d.delete(10);
    	d.deleteat(3);
    	d.find(17);
    	d.printfromfront();
    	d.printfromback();
    }
}
