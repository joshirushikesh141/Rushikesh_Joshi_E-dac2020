// inserting and removing elements into stack
class StackData
{
	private int[] stack;
	private int top;
	private int MAX=100;
	
	public StackData()
	{
		top = 0;
		stack= new int[MAX];
		System.out.println("Stack created");
	}
	
// inserting one element to stack
	public void push(int a)
	{
		if(top>=MAX)
			System.out.println("error:Stack is full");	
		else
			stack[top++]= a;   //adding new element
			//System.out.println("added element:"+stack);
	}
	
//removing one element from stack
	public int pop()
	{
		if(top<0)
		{
			System.out.println("error Stack is empty");
			return -1;   //-1 is just a number taken to represent empty stack
		}
		else
			return stack[--top];    //removing element
	}	
}
 
class BasicStack
{
	public static void main(String args[])
	{
		StackData sd = new StackData();
		sd.push(1234);
		sd.push(9876);
		//sd.push(4567);
		
		System.out.println("removed values are: "+sd.pop()+" "+sd.pop());

	}
}