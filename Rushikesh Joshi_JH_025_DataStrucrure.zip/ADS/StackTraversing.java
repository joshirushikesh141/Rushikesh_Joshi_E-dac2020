// Printing stack data
class Stackdata
{
	private int MAX= 100;
	private int top;
	int[] stack;
	
	Stackdata()
	{
		top=0;
		stack = new int[MAX];
	}
	
	public void push(int a)
	{
		if(top>=MAX)
		{
			System.out.println("Stack is full");
		}
		else
			stack[top++] = a;
	}
	
	public int pop()
	{
		if(top<0)
		{
			System.out.println("Stack is empty");
			return -1;
		}
		else
			return stack[--top];
	}
	
	public void print()
	{
		if(top<0)
		{
			System.out.println("currently stack is empty");
		}
		else
		{
			for(int i=top-1; i>=0; i--)
			{
				System.out.println(stack[i]);
			}
		}
	}
}

class StackTraversing
{
	public static void main(String args[])
	{
		Stackdata sd = new Stackdata();
		sd.print();
		sd.push(100);
		sd.push(101);
		sd.push(102);
		sd.push(103);
		sd.push(104);
		sd.push(105);
		sd.push(106);
		sd.push(107);
		sd.push(108);
		sd.push(109);
		sd.print();
		System.out.println("===============================");
		sd.pop();
		sd.pop();
		sd.pop();
		sd.pop();
		sd.pop();
		
		sd.print();
	}
}