// inserting and removing elements into stack----wth proper comments
public class MyStack      //Stack push() pop() functions
{
	private int[] stack;   //stack array
	private int top;     //variable taken to point current element
	private static int MAX = 2;   // vale initialised for stack size
	
	public MyStack()    // Constructor
	{
		top = 0;
		/*int[]*/ stack = new int[MAX];     //stack size becomes 100
		System.out.println("Stack Initialised");
	}
	
	public void push(int item)  //<<------Here we are inserting value
	{
		if(top>=MAX)
			System.out.println("Error: Stack overflow");
		else
			stack[top++]=item;   //increasing pointer to insert element
								 //ie. in stack[1] assign item 
	}     // value stored---10,7
	
	public int pop()  //<<------Here we are removing value
	{
		if(top <= 0)
		{
			System.out.println("Error: Stack is empty");
			return -1;  //<<--------here (-1) is just taking as indication for empty stack
		}						 // so don't confuse with -1
		else
			return stack[--top];   //decreasing pointer to remove value
	}
/*
	public boolean empty() //<<---------------??
	{
		return top == 0;
	}
	
	public int top() //<<-------------??
	{
		if (empty()) 
		{ 
			System.out.println("Error: top on empty stack"); 
			return -1;
		}
		else
			return stack[top-1];
	}
*/
	public static void main(String args[])
	{
		System.out.println("Inside Test");
		MyStack ms = new MyStack();
		ms.push(10);       //function used to insert value
		ms.push(7);        //function used to insert value
		ms.push(12);	   //stack overflow---stack space is 2 only
		
		System.out.println(" "+ ms.pop()+" \n"+ms.pop()+" \n"+ms.pop());  
		// Function used inside to remove the value from stack
	}
}















