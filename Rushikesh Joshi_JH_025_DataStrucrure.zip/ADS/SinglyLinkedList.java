public class SinglyLinkedList 
{
   private Node head;
   Node tail;
   int size;
   
   	public SinglyLinkedList()
   	{
	   head=null;
   	}
   	private boolean isEmpty() 
   	{
		return head==null;
	}
 	public void insertattop(int ele)
 	{
 		Node node=new Node(ele);
     	if(isEmpty())
     	{
    	 	head=node;
        	tail=node;
     	}
     	else
     	{
     		node.next=head;
     		head=node;
     	}
     	size++;
 	}
   
   	public void insertatend(int ele)
   	{
   		Node node=new Node(ele);
   		if(isEmpty())
   		{
   			head=node;
   			tail=node;
   		}
   		else
   		{
   			Node curr=head;
   			while(curr.next!=null)
   			{
   				curr=curr.next;			 
   			}
   			curr.next=node;
   		}
   	}
   	public void insertAfter(int key, int ele)
   	{
        Node node = new Node(ele);

        // find the position of key
        Node curr = head;
        while(null != curr && curr.data != key) {
            curr = curr.next;
        }

        if (null == curr) {
            System.out.println("Key not found");
            return;
        }

        if(null == curr.next) {
            curr.next = node;
        } else {
            Node next = curr.next;
            curr.next = node;
            node.next = next;
        }
    }
   	
   	public void insertAt(int position, int ele)
   	{
        Node node = new Node(ele);
       
        int i=0;
        // find the position of key
        Node curr = head;
        
        while(i<position-1) 
        {
            curr = curr.next;
            i++;
        }

        if (curr==null) 
        {
            System.out.println("Key not found");
            return;
        }

        if(curr.next==null) 
        {
            curr.next = node;
        } else {
            Node next = curr.next;
            curr.next = node;
            node.next = next;
        }
    }
   	
     public void print()
     {
    	 Node curr=head;
         if (isEmpty()) {
             System.out.println("List is Empty");
         } else {
        	
             while (curr != null) {
                 System.out.print(curr.data + " ");
                 curr = curr.next;
             }
             System.out.println();
         }
     }
     
     public void deleteattop()
     {
    	  if (isEmpty()) {
              System.out.println("List is empty");
          }
    	  
    	 Node next = head.next;
         //int item = head.data;
         head = next; 
     }
     
     public void deleteatlast()
     {
    	  if (isEmpty()) {
              System.out.println("List is empty");
          }
    	  
    	  Node curr = head;
          Node prev = null;
          while(curr.next != null) {
              prev = curr;
              curr = curr.next;
          }

          //int item = curr.data;

          if (prev == null) {
              // the list has only one item
              head = null;
          } else {
              prev.next = null;
              curr = null;
          }
     }
     public void delete(int key) {
         if (isEmpty()) {
             System.out.println("List is empty");
         }

         // find the position of the key
         Node curr = head;
         Node prev = null;

         while(curr != null && curr.data != key) {
             prev = curr;
             curr = curr.next;
         }

         if(curr == null) {
             System.out.print("key not found");
         }

         // if curr is head, delete the head
         if (prev == null) {
             head = head.next;
             curr = null;
         } else if (curr.next == null) { // if curr is last item
             prev.next = null;
             curr = null;
         } else { //anywhere between first and last node
             Node next = curr.next;
             prev.next = next;
             curr = null;
         }   
     }
   
     
     public void deleteat(int pos) {
         if (isEmpty()) {
             System.out.println("List is empty");
         }
         int i=0;
         // find the position of the key
         Node curr = head;
         Node prev = null;

         while(i<pos) {
             prev = curr;
             curr = curr.next;
             i++;
         }

         if(curr == null) {
             System.out.print("key not found");
         }

         // if curr is head, delete the head
         if (prev == null) {
             head = head.next;
             curr = null;
         } else if (curr.next == null) { // if curr is last item
             prev.next = null;
             curr = null;
         } else { //anywhere between first and last node
             Node next = curr.next;
             prev.next = next;
             curr = null;
         }   
     }
     
     void find(int key) {
    	    if (isEmpty()) {
    	    	System.out.println("List is empty");
    	    }

    	    Node curr = head;
    	    while (curr != null && curr.data != key) 
    	    {
    	        curr = curr.next;
    	    }

    	    if (curr == null) {
    	    	System.out.println("Key is not found");
    	    }
    	    else
    	    {
                System.out.println(curr.data+" "+"Key is found");
    	    }
    	}
     
   public static void main(String args[])
   {
	   SinglyLinkedList s=new SinglyLinkedList();
	   s.insertattop(10);
	   s.insertattop(20);
	   s.insertatend(30);
	   s.insertAfter(10, 15);
	   s.insertAfter(15, 17);
	   s.insertAt(2, 5);
	   s.print();
	   //s.deleteattop();
	   //s.deleteattop();
	   //s.deleteatlast();
	   s.delete(15);
	   s.deleteat(2);
	   s.find(15);
	   s.print();
   }
}
