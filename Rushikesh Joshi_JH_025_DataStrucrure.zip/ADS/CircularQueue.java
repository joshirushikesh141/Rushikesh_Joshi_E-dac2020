public class CircularQueue 
{
	int front=-1,rear=-1;
	int n=5;
	int[] a=new int[n];

	boolean isempty()
	{
		return (front==-1 && rear==-1);
	}
	
	void insert(int ele)
	{  
		if((rear+1)%n==front)
		{
			System.out.println("Queue is full");
		}
	
		if(front==-1 && rear==-1)		
    	{
          front=0;   
          rear=0;
	    }
		else if(rear == n-1 && front != 0)
			{
				rear=0;
			}
		else{
				rear = (rear+1)%n;
		    }
	     a[rear]=ele;
    }
	
	public void display()
	{
		 if(rear >= front) 
		    { 
		        for(int i = front; i <= rear; i++) 
		        { 
		            System.out.println(a[i]);
		        }
		    }
		 else
		 {
			 for(int i = front; i < n; i++) 
		        { 
		            System.out.println(a[i]);  
		        } 
		        for(int i = 0; i <= rear; i++) 
		        { 
		            System.out.println(a[i]);  
		        }
		 }
	}
	
	public void delete()
	{
		if(rear==-1 && front==-1)
		{
			System.out.println("Queue is Empty");
		}
		
		if(front==n-1)
		{
			front=0;
			
		}
		if(rear==front)
		{
			front=-1;
			rear=-1;
		}
		else
			front=front+1;
	}
	
	public static void main(String args[])
	{
		CircularQueue c=new CircularQueue();
		c.insert(10);
		c.insert(20);
		c.insert(30);
		c.insert(40);
		c.insert(50);
		c.display();
		c.delete();
		c.delete();
		c.insert(60);
		c.display();
	}
}