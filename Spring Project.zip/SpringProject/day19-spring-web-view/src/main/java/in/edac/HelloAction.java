package in.edac;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/hello")
public class HelloAction {
	
	@GetMapping("/")
	public String sayHello() {
		return "Hellooooo";
		
	}
	
	@GetMapping("/1")
	public String sayHi() {
		return "Hiiiiii";
		
	}
	
	@GetMapping("/2")
	public String hello() {
		return "Hello Springboot...!!";
		
	}

}
