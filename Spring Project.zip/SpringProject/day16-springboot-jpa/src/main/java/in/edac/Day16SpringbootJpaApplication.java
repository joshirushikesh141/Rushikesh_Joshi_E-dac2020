package in.edac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day16SpringbootJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day16SpringbootJpaApplication.class, args);
	}

	public void run() {
		
	}
}
