package in.edac;

public class SingletonDemo {
	
	public static void main(String[] args) {
		 System.out.println("Let's us study SpringBoot");
		 
		 UserDao ref1 = UserDao.getInstance();
		 System.out.println(ref1);
		 
		 UserDao ref2 = UserDao.getInstance();
		 System.out.println(ref2);
	}

}
