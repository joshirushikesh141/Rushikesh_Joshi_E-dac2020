package in.edac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day16SpringbootJpaRevisionApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day16SpringbootJpaRevisionApplication.class, args);
	}
	
	

}
