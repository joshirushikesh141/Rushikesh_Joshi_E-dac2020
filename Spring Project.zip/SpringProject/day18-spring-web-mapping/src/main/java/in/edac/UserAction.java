package in.edac;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
public class UserAction {

	@GetMapping("/")
	public String helloWorld() {
		return "Hello Spring...!!";
		
	}
	
	@GetMapping("/1")
	public String sayHii() {
		return "Hii....springboot";
		
	}
	
	@GetMapping("/2")
	public String sayHello() {
		return "Welcome to Springboot World...!!";
		
	}
}
