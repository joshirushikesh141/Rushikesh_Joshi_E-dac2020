import java.util.Scanner;
class Q10
{
   public static void main(String arg[])
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter temperature (in *F) : "); 
float F=sc.nextFloat();
float C= 5*(F-32)/9 ;
System.out.println("Enter temperature is (in *C) : "+C); 
}
}