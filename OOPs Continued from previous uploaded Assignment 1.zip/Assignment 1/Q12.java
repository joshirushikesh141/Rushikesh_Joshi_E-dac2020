import java.util.Scanner;
class Q12
{
public static void main(String args[])
{
double basic_scalary,da,hra,gpay;
Scanner sc= new Scanner(System.in);
System.out.println("Enter the basic_scalary");
basic_scalary=sc.nextDouble();
if(basic_scalary < 10000)
{
hra = (10 *basic_scalary) /100;
da = (90 *basic_scalary)/ 100;
}
else
{
hra = 2000;
da = (98*basic_scalary) /100;
}
gpay=basic_scalary+hra+da;
System.out.println("gross salary = " + gpay);


}
}
