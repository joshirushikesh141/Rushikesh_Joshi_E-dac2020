import java.util.Scanner;
class Q7
{
   public static void main(String arg[])
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter English Marks(out of 100): ");
int English = sc.nextInt();
System.out.println("Enter Math Marks(out of 100): ");
int Math = sc.nextInt();
System.out.println("Enter Science Marks(out of 100): ");
int Science = sc.nextInt();
System.out.println("Enter Geogrophy Marks(out of 100): ");
int Geogrophy = sc.nextInt();
System.out.println("Enter Economics Marks(out of 100): ");
int Economics = sc.nextInt();

int sum= English + Math + Science + Geogrophy + Economics;
float P = (float)(sum/5); 
int Percentage = (int)P;

System.out.println("percentage marks = "+Percentage+"%"); 
}
}