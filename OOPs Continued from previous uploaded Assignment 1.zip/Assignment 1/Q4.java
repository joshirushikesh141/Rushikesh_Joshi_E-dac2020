class Q4
{
public static void main(String arg[])
{
byte a =10;
byte b =20;
byte c =(a + b);
System.out.println(c);
}
}