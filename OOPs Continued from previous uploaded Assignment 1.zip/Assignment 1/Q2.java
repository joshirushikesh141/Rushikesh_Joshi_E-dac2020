class Q2
{
public static void main(String arg[])
{
int rollNo=100;
System.out.println("roll no=100");
}
}