class Q3
{
public static void main(String args[])
{
int x=5,y;
y=x*x+3*x-7;
System.out.println("y = "+y);


y=x++ + ++x;
System.out.println("value of x =" + x);
System.out.println("value of y =" +y);

int z;
z=x++ + --y - --x + x++;
System.out.println("values are x="+x +" y= "+y +" z= "+ z);
 
fun();
}
static void fun(){
boolean x=true;
boolean y=false;

boolean z= x && y|| !(x||y);
System.out.println("value of z is " + z);
}
}