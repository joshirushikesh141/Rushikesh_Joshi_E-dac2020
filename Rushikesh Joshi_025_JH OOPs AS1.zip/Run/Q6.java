import java.util.Scanner;
class Q6
{
public static void main(String arg[])
{
Scanner sc = new Scanner(System.in);
System.out.println("enter value of radius(in cm): ");
float r = sc.nextFloat();
System.out.println("Circumference of circle = "+ 2*Math.PI*r +" cm"); 
}
}