import java.util.Scanner;
class Q13
{
public static void main(String arg[])
{
Scanner sc =new Scanner(System.in);
System.out.println("Enter first value");
int a= sc.nextInt();
System.out.println("Enter second value");
int b= sc.nextInt();
System.out.println("Enter third value");
int c= sc.nextInt();

if(a>b && a>c)
{
System.out.println("a is Greatest");
}
else 
     if(b>a && b>c)
     {
       System.out.println("b is Greatest");
      }
     else
     {
      System.out.println("c is Greatest");
}
}
}