import java.util.Scanner;
class Q8
{  
   public static void main(String arg[])
{
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter Principal_ammount : ");
    int Principal_ammount = sc.nextInt();
    System.out.println("Enter Interest_rate : ");
    float Interest_rate = sc.nextFloat();
    
    System.out.println("Enter Time (in Years): ");
    int Time = sc.nextInt();
    
    float SI = Principal_ammount * Interest_rate * Time / 100 ;
    System.out.println("Simple Interest is = "+SI+" Rupees");
}
}