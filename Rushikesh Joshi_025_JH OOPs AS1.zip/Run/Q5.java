class Q5
{
public static void main(String arg[])
{

String s1 = arg[0];         //taking string argument at compilation
System.out.println("Welcome "+s1);     //printing argument
}
}