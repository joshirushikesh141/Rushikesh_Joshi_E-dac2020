import java.util.Scanner;
class TQ13
{
public static void main(String arg[])
{
Scanner sc =new Scanner(System.in);
System.out.println("Enter first value");
int a= sc.nextInt();
System.out.println("Enter second value");
int b= sc.nextInt();
System.out.println("Enter third value");
int c= sc.nextInt();

if(a>b && a>c)
{
System.out.println(a);
}
else
{
int d = (b>c)?b:c;
System.out.println(d);
}
}
}