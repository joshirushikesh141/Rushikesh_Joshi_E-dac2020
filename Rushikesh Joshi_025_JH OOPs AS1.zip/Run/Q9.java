import java.util.Scanner;
class Q9
{
public static void main(String arg[])
{
Scanner sc= new Scanner(System.in);
System.out.println("Enter no.of days: ");
int days = sc.nextInt();

if(days>=365)
{
int years= days/365;        // we get no. of years
System.out.println("number of years= "+ years);
days= days%365;        //current days remaining
}
if(days>=30)
{
int months= days/30;         //we get no. of months
System.out.println("number of months= "+ months);
days= days%30;            //we get no. of days
System.out.println("number of days= "+ days);
}
else
{
System.out.println("number of days= "+ days);
}
}
}