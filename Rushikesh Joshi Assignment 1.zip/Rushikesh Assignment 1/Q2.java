import java.util.Scanner;
class Q2 
{
      public static void main(String arg[])
      {
      Scanner value = new Scanner(System.in);
         int a= value.nextInt();
         int b= value.nextInt();
         int c=a+b;
         System.out.println(c);
      }
}