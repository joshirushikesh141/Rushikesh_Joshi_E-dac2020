import java.util.Scanner;
class Q6
{
      public static void main(String arg[])
      {
         Scanner value = new Scanner(System.in);
         int a= value.nextInt();
         int b= value.nextInt();
         int c=a+b;
         int d=a-b;
         int e=a*b;
         int f=a/b;
         int g=a%b;
         System.out.println("Input first number:"+a);
         System.out.println("Input second number:"+b);
         System.out.println(c);
         System.out.println(d);
         System.out.println(e);
         System.out.println(f);
         System.out.println(g);

      }
}