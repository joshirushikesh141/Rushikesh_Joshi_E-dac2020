//print hello
//Rushikesh Joshi

class Q1 
{
      public static void main(String arg[])
      {
         System.out.println("Hello");
         System.out.println("Rushikesh Joshi");
      }
}