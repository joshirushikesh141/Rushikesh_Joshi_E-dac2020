import java.util.Scanner;
class Q11 
{
      public static void main(String[] args)
      {
        Scanner value = new Scanner(System.in);

        System.out.println("enter radius: ");
        double radius = value.nextDouble();

        System.out.println("Perimeter is = " + (2*3.14*radius));
        System.out.println("Area is = " + (3.14*radius*radius));
 }
}