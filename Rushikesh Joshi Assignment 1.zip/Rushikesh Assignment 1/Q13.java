class Q13 
{
     public static void main(String[] strings)
     {

        double width = 5.6;
        double height = 8.5;

        double perimeter = 2*(height + width);
		
        double area = width * height;			
		
	System.out.println("Perimeter is :"+perimeter);

        System.out.println("Area is :"+area);
    }
}