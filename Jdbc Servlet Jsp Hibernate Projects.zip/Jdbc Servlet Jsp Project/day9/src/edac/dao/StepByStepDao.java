package edac.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;



public class StepByStepDao {
	
	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/edac";
	public static final String DB_USER = "root";
	public static final String DB_PASSWORD = "edac20";
	
	public void checkConnectionOld() {
		
		try {
			
			Class.forName(DB_DRIVER);
			
			Connection con =  DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
			
			con.close();
			System.out.println("Success!!!!");
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}
	
	
	public void checkConnection() {
		try (Connection con =  DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);) {
			
			Class.forName(DB_DRIVER);
			
			System.out.println("Successfully done with try with resources");
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}
	
	
	public boolean createUserV1() {
		
		try (Connection con =  DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);){
			
			Class.forName(DB_DRIVER);
			
			String sql = "INSERT INTO USER (Username,Pswd,Email,Mobile) VALUES (?, ?, ?, ?)";
			
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1,"Rushikesh " );
			ps.setString(2, "Rushi25");
			ps.setString(3, "rushikesh@gmail.com");
			ps.setString(4, "9836478292");
			
			ps.executeUpdate();
			System.out.println("Insert Successfully....!!");
			
			return true;
			
		} catch (Exception e) {
			
			e.printStackTrace();
			return false;
		}
		
	}
	
	
	public boolean createUserV2 (String username,String password, String email,  String mobile) {
		
		try(Connection con = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);) {
			
			Class.forName(DB_DRIVER);
			
			String sql = "INSERT INTO USER (Username,Pswd,Email,Mobile) VALUES (?, ?, ?, ?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			ps.setString(3, email);
			ps.setString(4, mobile);
			
			ps.executeUpdate();
			System.out.println("Insert Dynamicaly....!!");
			
			return true;
			
		} catch (Exception e) {
			
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean createUser(User user) {
		try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);) {
			Class.forName(DB_DRIVER);
			
			String sql = "INSERT INTO USER (Username,Pswd,Email,Mobile) VALUES (?, ?, ?, ?)";
			
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, user.getUsername());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getEmail());
			ps.setString(4, user.getMobile());
			
			ps.executeUpdate();
			System.out.println("Insert multiple entries dynamically..");
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public static void main(String[] args) {
		
		StepByStepDao dao = new StepByStepDao();
		
		//Check connection
		dao.checkConnectionOld();
		dao.checkConnection();
		
		//Calling method
		//dao.createUserV1();
		
		//dao.createUserV2("Rushabh", "rushabh12", "RushabhBhoyar@gmail.com", "987643566");
		
		User user = new User("Ruchit","ruchit18","RuchitRamugade@gmail.com","9345623480");
		dao.createUser(user);
	}

}
