package edac;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Servlet-7")
public class HelloServlet7 extends HttpServlet {

	@Override
	public void init() throws ServletException {
		
		System.out.println("Object Initialized!!!");
	}
	

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try {

			System.out.println("I am new version of Service method..!");

			PrintWriter out = response.getWriter();
			out.println("Hello Servlet 7");

		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	@Override
	public void destroy() {
		
		System.out.println("Object destroyed!!!");
	}
}
