package edac;

import java.io.PrintWriter;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HelloServlet5
 */
@WebServlet("/HelloServlet5")
public class HelloServlet5 extends HttpServlet {
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		
	
		try {
			PrintWriter out = response.getWriter();
			out.println("Servlet 5");
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
	}

}
