package in.edac.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDao {

	public static final String DB_DRIVER ="com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/roshani";
	public static final String DB_USER ="root";
	public static final String DB_PASSWORD ="edac20";
	
	public void checkConnection() {
		
		try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);){
			
			System.out.println("Connection checked");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public boolean createUser(User user) throws Exception {
		
		Class.forName(DB_DRIVER);
		try(Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);) {
			
			String sql = "INSERT INTO USER (USERNAME,PASSWORD,EMAIL,MOBILE) Values (?,?, ?, ?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, user.getUsername());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getEmail());
			ps.setString(4, user.getMobile());
			
			int n = ps.executeUpdate();
			System.out.println(n+ "" +" entries inserted successfully");
			
			return true;
		} catch (SQLException e) {
			
			e.printStackTrace();
			throw e;
		}
	
		
	}
	

	public boolean updateUser(User user) throws Exception {
		
		Class.forName(DB_DRIVER);
		
	try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);){
		
		String sql = "UPDATE USER SET USERNAME=?, PASSWORD=?, EMAIL=?, MOBILE=? where ID=?";
		PreparedStatement ps= con.prepareStatement(sql);
		
		ps.setString(1,user.getUsername());
		ps.setString(2, user.getPassword());
		ps.setString(3, user.getEmail());
		ps.setString(4, user.getMobile());
		ps.setInt(5, user.getId());
		
		int n = ps.executeUpdate();
		System.out.println(n + " " + "record Update Successfully");
		return true;
	
	} catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
	}
	
	public boolean deleteUser(User user) throws Exception {
		Class.forName(DB_DRIVER);
		
		try(Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);) {
			
			 String sql = "DELETE FROM USER WHERE ID=?";
			 PreparedStatement ps = con.prepareStatement(sql);
			 ps.setInt(1, user.getId());
			 
			 ps.executeUpdate();
			 
			 System.out.println("Record deleted.");
			 
			 return true;
			 
		}catch (Exception e){
			
			e.printStackTrace();
			return false;
		}
	}
	
public List<User> readAllUser() throws Exception{
	
	Class.forName(DB_DRIVER);
	
	try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);){
		
		String sql = "SELECT * FROM USER"
;		PreparedStatement ps = con.prepareStatement(sql);

		ResultSet rs = ps.executeQuery();
		List<User> list =  new ArrayList<User>();
		while(rs.next()) {
			
			int colId = rs.getInt("ID");
			String colUsername = rs.getString("USERNAME");
			String colEmail = rs.getString("EMAIL");
			String colMobile = rs.getString("MOBILE");
			
			User user = new User();
			user.setId(colId);
			user.setUsername(colUsername);
			user.setEmail(colEmail);
			user.setMobile(colMobile);
			
			list.add(user);
		}
		
		return list;
	} catch (Exception e) {
		
		e.printStackTrace();
		throw e;
	}
	
	
}
public static void main(String[] args) throws Exception {
	 UserDao dao = new UserDao();
	 
	 //User user = new User("Roshani","rosha13","roshani@gmail.com","9665149069");
	 //dao.createUser(user);
	 
	 //User user1 = new User("Rupali","rupali12","rupali@gmail.com","9665149069");
	 //dao.createUser(user1);
	 
	 
	// User user = new User("Mayuresh","mayur5","mayuresh@gmail.com","8976543901");
	 //user.setId(5);
	 //dao.updateUser(user);
	 
	 // delete user
	 //User user = new User();
	 //user.setId(3);
	 //dao.deleteUser(user);
	 
	 List<User> list = dao.readAllUser();
	 System.out.println(list);
}
	
}
