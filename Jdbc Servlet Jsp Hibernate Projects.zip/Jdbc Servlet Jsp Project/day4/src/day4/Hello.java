package day4;

import java.util.HashMap;
import java.util.Map;

public class Hello {
	public static void main(String[] args) {
		
		// HashMap<String, String> map = new HashMap<>();
		
		// Inheritance And Polymorphism
		
		Map<String, String> map = new HashMap<>();
		map.put("city","Mumbai");
		map.put("id", "100");
		
		String o1 = (String)map.get("city");
		
		Map<String, Object> map1 = new HashMap<>();
		map1.put("city","Nagpur");
		map1.put("id",100);
		
		String o2 = (String)map1.get("city");
		
		System.out.println(o1 + " " + o2);
		
	}

}
