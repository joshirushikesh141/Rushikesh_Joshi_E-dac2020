package in.edac;

import java.sql.Connection;
import java.sql.DriverManager;

public class HelloJdbc2 {
	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String url = "jdbc:mysql://localhost:3306/edac";
	public static final String DB_USER = "root";
	public static final String DB_PASSWORD = "edac20";
	
	public static void main(String[] args) {
		try {
			// Dynamic Loading!! the class Driver
			Class.forName(DB_DRIVER);
			
			
			// Open Connection
			Connection con = DriverManager.getConnection(url, DB_USER, DB_PASSWORD);

			System.out.println("Horray!!! DataBase Connected!!");
			// Exception Occured.
			
			// Close Connection
			con.close();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
	}

}
