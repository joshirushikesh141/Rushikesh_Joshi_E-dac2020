package in.edac;

import java.sql.Connection;
import java.sql.DriverManager;

public class HelloJdbc {

	public static void main(String[] args) {
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			String url = "jdbc:mysql://localhost:3306/edac";
			String user = "root";
			String password = "edac20";
			
			Connection con  = DriverManager.getConnection(url,user,password);
			
			System.out.println("Horray!!!! Database Connected" + con);
			
			con.close();
			
		  } catch (Exception e) {
			
			e.printStackTrace();
		}	
		
	}
}
