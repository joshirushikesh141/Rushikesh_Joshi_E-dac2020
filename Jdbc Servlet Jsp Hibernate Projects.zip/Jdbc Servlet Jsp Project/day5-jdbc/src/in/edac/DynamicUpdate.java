package in.edac;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class DynamicUpdate {
	
	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String url = "jdbc:mysql://localhost:3306/edac";
	public static final String DB_USER = "root";
	public static final String DB_PASSWORD = "edac20";
	
	public static void main(String[] args) throws Exception {
		
		Connection con = null;
		
		
		try {
			
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Enter Username");
			String username = sc.nextLine();
			
			System.out.println("Enter password");
			String password = sc.nextLine();
			
			System.out.println("Enter Email");
			String email = sc.nextLine();
			
			System.out.println("Enter Mobile");
			String mobile = sc.nextLine();
			
			System.out.println("WHERE ID = ");
			int id = sc.nextInt();
			
			sc.close();

			Class.forName(DB_DRIVER);
			
			con = DriverManager.getConnection(url, DB_USER,DB_PASSWORD);
			
			String sql = "UPDATE USER SET Username=?, Pswd=?, Email=?, Mobile=? "; 
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			ps.executeUpdate();
			
			System.out.println("Delete successfully....!!");
			
		} catch (Exception e) {
		
			e.printStackTrace();
			
		} finally {
			
			System.out.println("Finally block executed....!!");
			con.close();
		}
		
	}

}
